/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   set.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mkhoza <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/26 07:21:00 by mkhoza            #+#    #+#             */
/*   Updated: 2018/06/28 07:26:34 by mkhoza           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_ls.h"
#include <pwd.h>
#include <grp.h>
#include <time.h>

void	print_file_type(mode_t st_mode)
{
	if ((S_ISFIFO(st_mode)))
		printf("p");
	else if ((S_ISCHR(st_mode)))
		printf("c");
	else if ((S_ISDIR(st_mode)))
		printf("d");
	else if ((S_ISBLK(st_mode)))
		printf("b");
	else if ((S_ISREG(st_mode)))
		printf("-");
	else if ((S_ISLNK(st_mode)))
		printf("l");
	else if ((S_ISSOCK(st_mode)))
		printf("s");
	else
		printf(" ");
}

void	print_file_rights(mode_t st_mode)
{
	char *ret;

	ret = ft_strnew(10);
	ret[0] = ((st_mode & S_IRUSR) ? 'r' : '-');
	ret[1] = ((st_mode & S_IWUSR) ? 'w' : '-');
	ret[2] = ((st_mode & S_IXUSR) ? 'x' : '-');
	ret[2] = ((st_mode & S_ISUID) ? 'S' : ret[2]);
	ret[2] = (ret[2] == 'S' && (st_mode & S_IXUSR) ? 's' : ret[2]);
	ret[3] = ((st_mode & S_IRGRP) ? 'r' : '-');
	ret[4] = ((st_mode & S_IWGRP) ? 'w' : '-');
	ret[5] = ((st_mode & S_IXGRP) ? 'x' : '-');
	ret[5] = ((st_mode & S_ISGID) ? 'S' : ret[5]);
	ret[5] = (ret[5] == 'S' && (st_mode & S_IXGRP) ? 's' : ret[5]);
	ret[6] = ((st_mode & S_IROTH) ? 'r' : '-');
	ret[7] = ((st_mode & S_IWOTH) ? 'w' : '-');
	ret[8] = ((st_mode & S_IXOTH) ? 'x' : '-');
	ret[8] = ((st_mode & S_ISVTX) ? 'T' : ret[8]);
	ret[8] = (ret[8] == 'T' && (st_mode & S_IXOTH) ? 't' : ret[8]);
	printf("%s", ret);
	ft_strdel(&ret);
}

void	print_file_owner(uid_t st_uid, size_t max)
{
	struct passwd	*pass;
	size_t			len;

	if ((pass = getpwuid(st_uid)) != NULL)
	{
		printf("%s  ", pass->pw_name);
		len = ft_strlen(pass->pw_name);
		while ((max - len++) > 0)
			printf(" ");
	}
	else
	{
		printf("%s  ", ft_itoa(st_uid));
		len = ft_nblen(st_uid);
		while ((max - len++) > 0)
			printf(" ");
	}
}

void	print_file_group(gid_t gid, size_t max)
{
	struct group	*grp;
	size_t			len;

	if ((grp = getgrgid(gid)) != NULL)
	{
		printf("%s  ", grp->gr_name);
		len = ft_strlen(grp->gr_name);
		while ((max - len++) > 0)
			printf(" ");
	}
	else
	{
		printf("%s  ", ft_itoa(gid));
		len = ft_nblen(gid);
		while ((max - len++) > 0)
			printf(" ");
	}
}

void	print_file_time(time_t mtime)
{
	char	*tmp;
	time_t	now;

	now = time(0);
	tmp = ft_strdup(ctime(&mtime));
	write(1, tmp + 4, 7);
	if (mtime > now || now - mtime > 15778463)
	{
		printf(" ");
		write(1, tmp + 20, 4);
	}
	else
		write(1, tmp + 11, 5);
	printf(" ");
	ft_strdel(&tmp);
}
